@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        Product Listing &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <a href="{{ route('products.create') }}" class="btn btn-primary btn-sm">Add Product</a>
                    </div>
                    <div class="card-body">
                        <table id="product-table" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Description</th>
                                    <th>Category</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('scripts')
    <script>
        $(document).ready(function() {
            $('#product-table').DataTable({
                processing: true,
                serverSide: true,
                headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
}
                ajax: "{{ route('products.index') }}",
                columns: [
                    
                    { data: 'name', name: 'name' },
                    { data: 'price', name: 'price' },
                    { data: 'description', name: 'description' },
                    { data: 'category.name', name: 'category.name' },
                    { data: 'actions', name: 'actions', orderable: false, searchable: false }
                ]
            });
        });
    </script>
@endsection
