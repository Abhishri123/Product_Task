<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta  name="csrf-token" content="{{ csrf_token() }}">
        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div class="container pt-3">
              <button type="button" class="btn btn-primary" id="add_product">  Add Product </button>
              <table class="table table-bordered mt-3">
                  <thead class="bg-dark text-white">
                      <th>Sr.no</th>
                      <th>Name</th>
                      <th>Description</th>
                      <th>Price</th>
                      <!-- <th>Category</th> -->
                      <th>Action</th>
                  </thead>
                  <tbody id="list_product">
                      @foreach($products as $product)
                        <tr id="row_product_{{ $product->id}}">
                            <td width="20">{{ $product->id}}</td>
                            <td>{{ $product->name}}</td>
                            <td>{{ $product->description}}</td>
                            <td>{{ $product->price}}</td>
                            <!-- <td>{{ $product->name}}</td> -->

                            <td width="150">
                                <button type="button" id="edit_product" data-id="{{ $product->id }}" class="btn btn-sm btn-info ml-1">Edit</button>

                                <button type="button" id="delete_product" data-id="{{ $product->id }}" class="btn btn-sm btn-danger ml-1">Delete</button>
                            </td>
                        </tr>
                      @endforeach
                  </tbody>
              </table>


        </div>

          <!-- The Modal -->
          <div class="modal" id="modal_product">
            <div class="modal-dialog">
              <div class="modal-content">
                <form id="form_product">
                    <div class="modal-header">
                      <h4 class="modal-title" id="modal_title"></h4>
                    </div>
                    <!-- Modal body -->
                    <div class="modal-body">
                      <input type="hidden" name="id" id="id">
                      <input type="text" name="name" id="name_product" class="form-control" placeholder="Enter Name ...">
                      <br>
                      <input type="text" name="description" id="description" class="form-control" placeholder="Enter description ...">
                      <br>
                      <input type="text" name="price" id="price" class="form-control" placeholder="Enter price ...">
                      <br>
                      <input type="text" name="category" id="caegory" class="form-control" placeholder="select category">
                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      <button type="submit" class="btn btn-info">Submit</button>
                      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>
                
              </div>
            </div>
          </div>
          
        </div>

        <script type="text/javascript">

            $(document).ready(function(){
                $.ajaxSetup({
                    headers:{
                        'x-csrf-token' : $('meta[name="csrf-token"]').attr('content')
                    }
                });
            });



$("#add_product").on('click',function(){
    $("#form_product").trigger('reset');
    $("#modal_title").html('Add Product');
    $("#modal_product").modal('show');
    $("#id").val("");
});

            $("body").on('click','#edit_product',function(){
                var id = $(this).data('id');
                $.get('products/'+id+'/edit',function(res){
                    $("#modal_title").html('Edit Todo');
                    $("#id").val(res.id);
                    $("#name_product").val(res.name);
                    $("#modal_product").modal('show');
                });
            });

            // Delete Todo 
            $("body").on('click','#delete_product',function(){
                var id = $(this).data('id');
                confirm('Are you sure want to delete !');

                $.ajax({
                    type:'DELETE',
                    url: "products/destroy/" + id
                }).done(function(res){
                    $("#row_product_" + id).remove();
                });
            });

            //save data 
            
            $("form").on('submit',function(e){
                e.preventDefault();
                $.ajax({
                    url:"product/store",
                    data: $("#form_product").serialize(),
                    type:'POST'
                }).done(function(res){
                    var row = '<tr id="row_product_'+ res.id + '">';
                    row += '<td width="20">' + res.id + '</td>';
                    row += '<td>' + res.name + '</td>';
                    row += '<td width="150">' + '<button type="button" id="edit_product" data-id="' + res.id +'" class="btn btn-info btn-sm mr-1">Edit</button>' + '<button type="button" id="delete_product" data-id="' + res.id +'" class="btn btn-danger btn-sm">Delete</button>' + '</td>';

                    if($("#id").val()){
                        $("#row_product_" + res.id).replaceWith(row);
                    }else{
                        $("#list_product").prepend(row);
                    }

                    $("#form_product").trigger('reset');
                    $("#modal_product").modal('hide');

                });
            });



        </script>
    </body>
</html>
